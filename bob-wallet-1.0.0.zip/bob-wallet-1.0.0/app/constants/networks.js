export const NETWORKS = {
  SIMNET: 'simnet',
  TESTNET: 'testnet',
  MAINNET: 'main',
  REGTEST: 'regtest'
};
export const VALID_NETWORKS = {
  simnet: 'simnet',
  testnet: 'testnet',
  main: 'main',
  regtest: 'regtest'
};
